package qtestDemo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestCase1 {


	@Test
	void test1() {
		assertEquals(1,3);
		
	}
	
	@Test
	void test2() {
		assertEquals(1,2);
	}
	
	@Test
	void test3() {
		assertEquals(1,1);
	}
}
